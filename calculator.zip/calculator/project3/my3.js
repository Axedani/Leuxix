bar = document.getElementById("bar");
cross = document.getElementById("close");
nav = document.querySelector(".nav");

if(bar){
	bar.addEventListener("click",()=>{
		nav.classList.add("active");
	});
}
if(cross){
	cross.addEventListener("click",()=>{
		nav.classList.remove("active");
	});
}