import { cart, cartQuantity } from "./my1-3.js";
import { products } from "./my1-2.js";
