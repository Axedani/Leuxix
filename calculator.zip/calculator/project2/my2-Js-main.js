import { sidebarElements } from "./my2-Js-data.js";

let options = "";
sidebarElements.forEach((element) => {
    options += `
        <div class="js-options">
           <a href="my2-Html-${element.image}.html"> <button class="js-link" data-element-name = ${element.name}> <img src="my2-nav-${element.image}.png"></button></a>
            <div>${element.name}</div>
        </div>
   `;
});
document.querySelector(".sidebar").innerHTML = options;

document.querySelector(".hide").addEventListener("click", () => {
    const hide = "";
    if (true) {
        document.querySelector(".sidebar").innerHTML = hide;
    }
});
document.querySelector(".show").addEventListener("click", () => {
    const show = options;
    if (true) {
        document.querySelector(".sidebar").innerHTML = options;
    }
});
