import { sidebarElements } from "./my2-data.js";
let space = "";
document.querySelectorAll(".js-link").forEach((link) => {
    link.addEventListener("click", () => {
        const elementName = link.dataset.elementName;
        let spaceElement;
        sidebarElements.forEach((element) => {
            if (element.name === elementName) {
                spaceElement = element;
            }
        });
        console.log(spaceElement.name);
    });
});
document.querySelector(".space").innerHTML = space;
