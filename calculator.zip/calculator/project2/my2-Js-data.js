export const sidebarElements = [
    {
        name: "Mathematiques",
        image: "math"
    },
    {
        name: "Pysique-Chimie",
        image: "pc"
    },
    {
        name: "Informatique",
        image: "info"
    },
    {
        name: "Philo-Lettre",
        image: "philolettre"
    },
    {
        name: "Sciences-Ingenieures",
        image: "si"
    },
    {
        name: "Anglais",
        image: "eng"
    },
    {
        name: "DS",
        image: "ds"
    },
    {
        name: "Concours",
        image: "concours"
    },
    {
        name: "Aide",
        image: "aide"
    }
];
